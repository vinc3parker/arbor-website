'use client';

import React, { useEffect, useMemo, useRef, useState } from 'react';
import styles from './ArborEightDimensions.module.css';

type AppStatus = 'dev' | 'beta' | 'live';

type ArborApp = {
  key: string;
  name: string;
  dimension: string;
  line: string;
  accent: string;
  status: AppStatus;
};

const APPS: ArborApp[] = [
  { key: 'nura', name: 'Nura', dimension: 'Financial Wellbeing', line: 'Build a steady foundation.', accent: '#1F6F78', status: 'dev' },
  { key: 'wend', name: 'Wend', dimension: 'Life Experiences', line: 'Explore what is out there.', accent: '#F28C28', status: 'dev' },
  { key: 'salus', name: 'Salus', dimension: 'Mental Wellbeing', line: 'Tend to your mind.', accent: '#38C5A2', status: 'beta' },
  { key: 'aevo', name: 'Aevo', dimension: 'Physical Wellbeing', line: 'Care for your body.', accent: '#D4FF00', status: 'beta' },
  { key: 'telos', name: 'Telos', dimension: 'Purpose & Contribution', line: 'Move towards what matters.', accent: '#C89B3C', status: 'dev' },
  { key: 'sage', name: 'Sage', dimension: 'Lifelong Growth', line: 'Keep learning, always.', accent: '#5C6BC0', status: 'dev' },
  { key: 'kith', name: 'Kith', dimension: 'Meaningful Connection', line: 'Stay close to your people.', accent: '#D96C8A', status: 'dev' },
  { key: 'thrive', name: 'Thrive', dimension: 'Intentional Living', line: 'Shape the space you live in.', accent: '#E85D5D', status: 'dev' },
];

const statusCopy: Record<AppStatus, string> = {
  dev: 'In development',
  beta: 'Beta',
  live: 'Live',
};

const tierCount: Record<AppStatus, number> = { dev: 1, beta: 2, live: 3 };

function clamp(value: number, min = 0, max = 1) {
  return Math.min(max, Math.max(min, value));
}

function smoothstep(start: number, end: number, value: number) {
  const t = clamp((value - start) / (end - start));
  return t * t * (3 - 2 * t);
}

function useScrollProgress(ref: React.RefObject<HTMLElement | null>) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let frame = 0;

    const update = () => {
      frame = 0;
      const el = ref.current;
      if (!el) return;

      const rect = el.getBoundingClientRect();
      const viewport = window.innerHeight || 1;
      const distance = Math.max(1, rect.height - viewport);
      setProgress(clamp(-rect.top / distance));
    };

    const requestUpdate = () => {
      if (frame) return;
      frame = window.requestAnimationFrame(update);
    };

    update();
    window.addEventListener('scroll', requestUpdate, { passive: true });
    window.addEventListener('resize', requestUpdate);

    return () => {
      if (frame) window.cancelAnimationFrame(frame);
      window.removeEventListener('scroll', requestUpdate);
      window.removeEventListener('resize', requestUpdate);
    };
  }, [ref]);

  return progress;
}

function AppGlyph({ appKey }: { appKey: string }) {
  return (
    <svg viewBox="0 0 120 180" className={styles.glyph} aria-hidden="true">
      {appKey === 'aevo' && (
        <>
          <circle cx="60" cy="48" r="8" />
          <path d="M60 57 C52 78 69 91 61 113 C57 128 67 139 62 154" />
          <path d="M59 75 C46 85 37 78 29 84" />
          <path d="M62 76 C75 86 83 78 92 84" />
          <path d="M62 126 C53 137 45 143 39 160" />
          <path d="M63 129 C75 140 79 149 84 166" />
          <path d="M25 145 C48 116 72 116 95 145" strokeDasharray="4 8" />
        </>
      )}
      {appKey === 'salus' && (
        <>
          <circle cx="60" cy="72" r="12" />
          <circle cx="60" cy="72" r="26" />
          <circle cx="60" cy="72" r="42" />
          <path d="M24 124 C42 116 52 132 60 124 C70 132 80 116 96 124" />
          <path d="M30 146 C45 140 53 152 60 146 C68 152 77 140 90 146" />
        </>
      )}
      {appKey === 'nura' && (
        <>
          <rect x="35" y="116" width="50" height="22" rx="3" />
          <rect x="41" y="91" width="38" height="22" rx="3" />
          <rect x="47" y="68" width="26" height="20" rx="3" />
          <rect x="53" y="48" width="14" height="16" rx="3" />
          <path d="M26 154 C43 148 52 160 60 154 C70 148 78 160 96 154" />
        </>
      )}
      {appKey === 'thrive' && (
        <>
          <path d="M32 100 L60 72 L88 100 L88 150 L32 150 Z" />
          <path d="M53 150 L53 120 L67 120 L67 150" />
          <circle cx="60" cy="52" r="4" />
        </>
      )}
      {appKey === 'wend' && (
        <>
          <circle cx="60" cy="58" r="15" />
          <line x1="28" y1="92" x2="92" y2="92" />
          <path d="M60 155 C46 141 75 129 63 113 C53 101 67 96 60 88" />
          <circle cx="64" cy="113" r="2" />
          <circle cx="52" cy="137" r="2" />
        </>
      )}
      {appKey === 'kith' && (
        <>
          <circle cx="60" cy="58" r="9" />
          <circle cx="34" cy="97" r="7" />
          <circle cx="86" cy="97" r="7" />
          <circle cx="47" cy="138" r="7" />
          <circle cx="78" cy="136" r="7" />
          <path d="M55 65 L38 91 M66 65 L82 91 M37 104 L45 132 M84 104 L79 130 M54 138 L71 137" />
        </>
      )}
      {appKey === 'sage' && (
        <>
          <path d="M60 154 L60 92" />
          <path d="M60 116 C47 106 40 94 34 80" />
          <path d="M60 103 C74 92 81 80 86 65" />
          <path d="M60 132 C51 124 44 116 40 105" />
          <path d="M60 123 C70 115 76 107 80 96" />
          <circle cx="34" cy="80" r="4" />
          <circle cx="86" cy="65" r="4" />
          <circle cx="60" cy="92" r="4" />
        </>
      )}
      {appKey === 'telos' && (
        <>
          <circle cx="60" cy="42" r="4" />
          <path d="M60 34 L60 24 M60 50 L60 60 M51 42 L41 42 M69 42 L79 42" />
          <path d="M23 150 L50 92 L63 119 L80 76 L98 150" />
          <path d="M60 150 C58 130 70 123 62 108 C56 96 67 84 60 69" strokeDasharray="4 8" />
        </>
      )}
    </svg>
  );
}

export default function ArborEightDimensions() {
  const heroRef = useRef<HTMLDivElement | null>(null);
  const progress = useScrollProgress(heroRef);
  const [activeKey, setActiveKey] = useState<string | null>(null);
  const [selectedApp, setSelectedApp] = useState<ArborApp | null>(null);

  const activeApp = useMemo(
    () => APPS.find((app) => app.key === activeKey) ?? null,
    [activeKey]
  );

  const introOpacity = 1 - smoothstep(0, 0.08, progress);
  const roomReveal = smoothstep(0.04, 0.2, progress);
  const archesReveal = smoothstep(0.16, 0.75, progress);
  const hintOpacity = smoothstep(0.74, 0.95, progress);

  return (
    <>
      <section className={styles.hero} ref={heroRef}>
        <div className={styles.stage}>
          <div className={styles.atmosphere} />

          <div
            className={styles.intro}
            style={{ opacity: introOpacity, transform: `translateY(${-28 * (1 - introOpacity)}px)` }}
          >
            <div className={styles.introWord}>Arbor</div>
            <div className={styles.introSub}>Scroll to enter</div>
          </div>

          <div className={styles.room} style={{ opacity: roomReveal }}>
            <div className={styles.floor} />
            <div className={styles.roots} aria-hidden="true">
              {APPS.map((app, index) => (
                <span
                  key={app.key}
                  className={styles.rootLine}
                  style={
                    {
                      '--accent': app.accent,
                      '--i': index,
                      opacity: archesReveal * (app.status === 'dev' ? 0.38 : 0.72),
                    } as React.CSSProperties
                  }
                />
              ))}
            </div>
          </div>

          <div className={styles.archGrid} style={{ '--reveal': archesReveal } as React.CSSProperties}>
            {APPS.map((app, index) => {
              const offset = index - (APPS.length - 1) / 2;
              const reveal = smoothstep(0.18 + Math.abs(offset) * 0.035, 0.38 + Math.abs(offset) * 0.035, progress);
              const isActive = activeKey === app.key;

              return (
                <button
                  key={app.key}
                  type="button"
                  className={`${styles.arch} ${isActive ? styles.active : ''}`}
                  style={
                    {
                      '--accent': app.accent,
                      '--x': `${offset * 66}%`,
                      '--z': `${Math.abs(offset) * -22}px`,
                      '--r': `${offset * -4}deg`,
                      opacity: reveal * (activeKey && !isActive ? 0.34 : app.status === 'dev' ? 0.62 : 1),
                      transform: `translateX(${offset * 66}%) translateY(${(1 - reveal) * 80}px) rotate(${offset * -4}deg)`,
                    } as React.CSSProperties
                  }
                  onMouseEnter={() => setActiveKey(app.key)}
                  onMouseLeave={() => setActiveKey(null)}
                  onFocus={() => setActiveKey(app.key)}
                  onBlur={() => setActiveKey(null)}
                  onClick={() => setSelectedApp(app)}
                  aria-label={`Open ${app.name}`}
                >
                  <span className={styles.archGlow} />
                  <span className={styles.archGlass}>
                    <AppGlyph appKey={app.key} />
                    <span className={styles.archName}>{app.name}</span>
                  </span>
                  <span className={styles.archFrame} />
                </button>
              );
            })}
          </div>

          <div className={`${styles.detail} ${activeApp ? styles.detailVisible : ''}`}>
            {activeApp && (
              <>
                <div className={styles.detailName}>{activeApp.name}</div>
                <div className={styles.detailDim} style={{ color: activeApp.accent }}>{activeApp.dimension}</div>
                <div className={styles.detailLine}>{activeApp.line}</div>
                <div className={styles.statusRow}>
                  <span className={styles.pips}>
                    {[1, 2, 3].map((n) => (
                      <span
                        key={n}
                        className={`${styles.pip} ${n <= tierCount[activeApp.status] ? styles.pipOn : ''}`}
                        style={{ '--accent': activeApp.accent } as React.CSSProperties}
                      />
                    ))}
                  </span>
                  {statusCopy[activeApp.status]}
                </div>
              </>
            )}
          </div>

          <div className={styles.hint} style={{ opacity: activeKey ? 0 : hintOpacity }}>
            Hover an archway to explore
          </div>
        </div>
      </section>

      <section className={styles.siteSection}>
        <div className={styles.siteInner}>
          <p className={styles.eyebrow}>The ecosystem</p>
          <h2>One system for a well-lived life.</h2>
          <p className={styles.lead}>Arbor is eight dimensions of one life, built to work together.</p>
          <div className={styles.cards}>
            {APPS.map((app) => (
              <a key={app.key} href={`/${app.key}`} className={styles.card} style={{ '--accent': app.accent } as React.CSSProperties}>
                <span>{app.dimension}</span>
                <strong>{app.name}</strong>
                <p>{app.line}</p>
              </a>
            ))}
          </div>
        </div>
      </section>

      {selectedApp && (
        <div className={styles.portal} style={{ '--accent': selectedApp.accent } as React.CSSProperties} role="dialog" aria-modal="true">
          <button className={styles.close} type="button" onClick={() => setSelectedApp(null)} aria-label="Close">
            ×
          </button>
          <div className={styles.portalArt}><AppGlyph appKey={selectedApp.key} /></div>
          <div className={styles.portalContent}>
            <span>{selectedApp.dimension}</span>
            <h2>{selectedApp.name}</h2>
            <p>{selectedApp.line}</p>
            <a href={`/${selectedApp.key}`}>Enter {selectedApp.name} →</a>
          </div>
        </div>
      )}
    </>
  );
}
